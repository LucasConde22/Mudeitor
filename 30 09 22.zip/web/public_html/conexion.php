<?php
    $servidor = "localhost";
    $usuario = "root";
    $contraseña = "";
    $base = "comentarios_database";

    $conn = mysqli_connect($servidor, $usuario, $contraseña, $base);

    if (!$conn){
        die("<script>alert('La conexión falló.')</script>");
}
?>